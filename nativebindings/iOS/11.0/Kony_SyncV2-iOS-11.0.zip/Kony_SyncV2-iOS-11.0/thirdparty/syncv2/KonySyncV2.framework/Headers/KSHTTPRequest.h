//
//  KSHTTPRequest.h
//  SyncNetworkUtil
//
//  Created by Girish Lingarajappa Haniyamballi on 28/11/16.
//  Copyright © 2016 Girish Lingarajappa Haniyamballi. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 enum to specify request method

 - KSHTTPMethodGet      : Maps to GET service call
 - KSHTTPMethodPost     : Maps to POST service call
 - KSHTTPMethodPut      : Maps to PUT service call
 - KSHTTPMethodDelete   : Maps to DELETE service call
 - KSHTTPMethodHead     : Maps to HEAD service call
 - KSHTTPMethodPatch    : Maps to PATCH service call
 - KSHTTPMethodNone     : Maps to GET service call-Default
 */
typedef NS_ENUM(NSUInteger, KSHTTPMethod) {
    KSHTTPMethodGet = 0,
    KSHTTPMethodPost,
    KSHTTPMethodPut,
    KSHTTPMethodDelete,
    KSHTTPMethodHead,
    KSHTTPMethodPatch,
    KSHTTPMethodNone = KSHTTPMethodGet
};

/**
 KSHTTPRequest 
 Constructs a request object based on user configuration. This is used by KSHTTPRequestInvoker to 
 create appropriate Sessions and tasks.
 */
@interface KSHTTPRequest : NSObject

/**
 Specifies the HTTP Method post/get/delete/.. for the created request. Default is <code>KSHTTPMethodGet</code>.
 */

@property(nonatomic, assign) KSHTTPMethod method;

/**
 Parameters set to the request
 */
@property(nonatomic, strong) NSDictionary *_Nullable parameters;

/**
 Sets the request body data of the request. This is sent as the message body of the HTTP POST request.
 */
@property(nonatomic, copy) NSData *_Nullable body;


@property(nonatomic, strong) NSString *_Nonnull url;

/**
 Returns the actual NSURLRequest object.
 */
@property(nonatomic, readonly) NSURLRequest *_Nullable actualNSURLRequest;


- (_Nullable instancetype)init __attribute__((unavailable("Must use initWithURL: instead.")));

/**
 Returns a request object created with a URL.

 @param URL URL is the endpoint url with which the request is initialised
 @return Returns an instance of the <code>KSHTTPRequest</code>.
 */
- (_Nullable instancetype)initWithURL:(NSString *_Nonnull)url;

/**
 Sets the value of the given HTTP header field. If a value was previously set for the given header
 field, that value is replaced with the given value.

 @param valueString The header field value.
 @param headerName The header field name (case-insensitive).
 */
- (void)setValue:(NSString *_Nonnull)valueString forHeader:(NSString *_Nonnull)headerName;

/**
 Removes a given HTTP header field from the request.

 @param headerName Name of the header field to be removed from the Request.
 */
- (void)removeHeader:(NSString *_Nonnull)headerName;

/**
 Validates if the request Object is valid. As a part of this the URL is validated.

 @return A boolean indicating if the request object is valid or not.
 */
- (BOOL)isValidRequest;

/**
 Util method to return string representation of the HTTP method.

 @param method KSHTTPMethod type
 @return returns string form of method type i.e. for KSHTTPMethodGet it returns @"GET"
 */
NSString *_Nullable NSStringFromKSHTTPMethod(KSHTTPMethod method);

@end
