//
//  MetadataConstants.h
//  KonySyncV2
//
//  Created by Harshini Bonam on 09/11/16.
//  Copyright © 2016 Kony. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KSConstants.h"

#define UNNAMED_NAMESPACE @"kony_unnamed"
#define UNNAMED_NAMESPACE_WITH_DOT @"kony_unnamed."
#define UNNAMED_OBJECT_GROUP @"kony_unnamed_object_group"

// -------------------------
// Constants for SQL queries
// -------------------------
#define SQL_CREATE @"CREATE TABLE IF NOT EXISTS "
#define SQL_DELETE @"DELETE FROM "
#define SQL_UPDATE @"ALTER TABLE "
#define SQL_DROP @"DROP TABLE "

// -------------------------------------------------------
// Constants for Metadata JSON object top-level properties
// -------------------------------------------------------
#define OP_STATUS @"opstatus"
#define DELTA_CONTEXT_VALUE @"delta_context_value"
#define HTTP_STATUS_CODE @"httpStatusCode"
#define ERR_MSG @"errmsg"
#define INTERMEDIATE_ERR_MSG @"intermediateErrors"
#define TIMESTAMP @"timestamp"
#define SYNC_CONFLICT_RESOLUTION_POLICY @"syncConflictResolutionPolicy"

// -------------------------
// Constants for Namespaces
// -------------------------
#define NAMESPACES @"namespaces"
#define NAMESPACES_NAME @"name"
#define NAMESPACES_ACTION @"action"

// -------------
// Batching keys
// -------------
#define BATCH_CONTEXT @"batch_context"
#define BATCH_ID @"batchid"
#define DEFAULT_BATCH_SIZE @(500)
#define DEFAULT_UPLOAD_BATCH_SIZE @(50)
#define BATCH_SIZE_FILTER @"$batchsize"
#define DEFAULT_BATCH_NUMBER @(1)
#define DEFAULT_RSN_OF_PREVIOUS_BATCH -1

// ----------------------------
// Constants for Tables/Objects
// ----------------------------
#define OBJECTS @"objects"
#define OBJECTS_NAME @"name"
#define OBJECTS_KEY @"key"
#define OBJECTS_OFFLINE @"offline"
#define OBJECTS_CACHE_TIMEOUT @"cache_timeout"
#define OBJECTS_FIELDS @"fields"
#define OBJECTS_RELATIONSHIPS @"relationships"
#define OBJECTS_ACTION @"action"
#define OBJECTS_GROUP @"object_group"
#define OBJECTS_SOFT_DELETE_FIELD @"softdelete_field"
#define RECORDS @"records"

// ------------------------
// Constants for Attributes
// ------------------------
#define ATTRIBUTES @"fields"
#define ATTRIBUTES_NAME @"name"
#define ATTRIBUTES_DATATYPE @"datatype"
#define ATTRIBUTES_LENGTH @"length"
#define ATTRIBUTES_SOURCE_DATATYPE @"source_datatype"
#define ATTRIBUTES_AUTO_GENERATED @"auto_generated"
#define ATTRIBUTES_NULLABLE @"nullable"
#define ATTRIBUTES_CREATABLE @"creatable"
#define ATTRIBUTES_UPDATABLE @"updatable"
#define ATTRIBUTES_ACTION @"action"

// -------------------------------------
// Constants for Attribute-Relationships
// -------------------------------------
#define RELATIONSHIP_NAME @"name"
#define RELATIONSHIP_TYPE @"type"
#define RELATIONSHIP_ACTION @"action"
#define RELATIONSHIP_TARGET_OBJECT @"target_object"
#define RELATIONSHIP_TARGET_ATTRIBUTES @"target_fields"
#define RELATIONSHIP_SOURCE_ATTRIBUTES @"source_fields"
#define RELATIONSHIP_CASCADE @"cascade"
#define RELATIONSHIP_BACKEND_CASCADE_SUPPORT @"backend_cascade_support"

// -------------------------------------
// Constants for Object-Operations
// -------------------------------------
#define OPERATIONS @"operations"
#define OPERATION_TYPE @"type"
#define OPERATION_SUPPORTED_OBJECTS @"supportedObjects"
#define OPERATION_OBJECT_NAME @"name"
#define OPERATION_ACTION @"actions"
#define OPERATION_GET @"get"
#define OPERATION_CREATE @"create"
#define OPERATION_UPDATE @"update"
#define OPERATION_PARTIAL_UPDATE @"partialupdate"
#define OPERATION_DELETE @"delete"


// -------------------------------------
// Constants for TABLE TYPE
// -------------------------------------
#define TABLE_TYPE_ORIGINAL @"ORIGINAL"
#define TABLE_TYPE_MAIN @"MAIN"
#define TABLE_TYPE_HISTORY @"HISTORY"

//----------------------------------
// Download response metadata keys
//----------------------------------

#define RECORD_COUNT_KEY @"recordCount"
#define UPDATED_RECORDS_KEY @"updatedRecords"
#define PARTIAL_UPDATED_RECORDS_KEY @"partialUpdatedRecords"
#define DELETED_RECORDS_KEY @"deletedRecords"


//------------------------
//CLASS NAMES IN METADATA
//------------------------
#define NAMESPACE_METADATA @"NamespaceMetadata"
#define OBJECT_METADATA @"ObjectMetadata"
#define ATTRIBUTE_METADATA @"AttributeMetadata"

//Metadata Table constants
#define METADATA_TABLE_OBJECT_SERVICE_NAME_ATTRIBUTE @"objectServiceName"
#define METADATA_TABLE_METADATA_JSON_ATTRIBUTE @"metadataJSON"
#define METADATA_TABLE_DELTA_CONTEXT_ATTRIBUTE @"deltaContext"

//Default Values
#define DEFAULT_REPLAY_SEQUENCE_NUMBER @(-1)

//Miscellaneous
#define SYNC_EMPTY_NAMESPACE_NAME @""
#define SYNC_EMPTY_OBJECT_SERVICE_NAME @""

// OData queries
#define OFFLINE_FLAG_TRUE @"offline=true"
#define OFFLINE_QUERY_PARAM @"offline"
#define TRUE_VALUE_QUERY_PARAM @"true"
#define METADATA_KEYWORD @"$metadata"

//Default Values
#define DEFAULT_REPLAY_SEQUENCE_NUMBER @(-1)

//extern NSString *const OBJECT_OR_ALL_KEY;

//ObjectAttribute related constants

typedef enum
{
    /*
     INT,
     INTEGER,
     TINYINT,
     SMALLINT,
     MEDIUMINT,
     BIGINT,
     UNSIGNED_BIG_INT,
     INT2,
     INT8
     */
    KSObjectAttributeDataTypeInteger = 0,
    KSObjectAttributeDataTypeNumber,
    KSObjectAttributeDataTypeBoolean,
    
    /*
     CHARACTER,
     VARCHAR,
     VARYING_CHARACTER,
     NCHAR,
     NATIVE_CHARACTER,
     NVARCHAR,
     TEXT,
     CLOB
     */
    KSObjectAttributeDataTypeText,
    KSObjectAttributeDataTypeString,
    
    /*
     BLOB
     BINARY
     */
    KSObjectAttributeDataTypeBlob,
    KSObjectAttributeDataTypeBinary,
    
    /*
     REAL,
     DOUBLE,
     DOUBLE_PRECISION,
     FLOAT
     */
    KSObjectAttributeDataTypeReal,
    
    /*
     NUMERIC,
     DECIMAL,
     BOOLEAN,
     DATE,
     DATETIME
     */
    KSObjectAttributeDataTypeNumeric,
    KSObjectAttributeDataTypeDate,
    
    KSObjectAttributeDataTypeCount //number of datatypes in the enum.
}KSObjectAttributeDataType;

extern NSString *dataTypeName (KSObjectAttributeDataType dataType);
extern KSObjectAttributeDataType dataTypeFromString (NSString * dataTypeString);

// Root metadata related constants

typedef enum
{
    KSSyncConflictResolutionPolicyNone = 0,
    KSSyncConflictResolutionPolicyServerWin,
    KSSyncConflictResolutionPolicyClientWin,
    KSSyncConflictResolutionPolicyCustom
}KSSyncConflictResolutionPolicy;

typedef enum
{
    KSActionCreate = 0, //post
    KSActionDelete, //delete
    KSActionUpdate, // patch, InsertOrCreate = putg
    KSActionNone = KSActionCreate
}KSAction;

extern KSAction actionFromString(NSString * actionName);

//Relationship related constants

typedef enum
{
    KSRelationshipTypeNone = 0,
    KSRelationshipTypeOneToMany,
    KSRelationshipTypeManyToOne,
    KSRelationshipTypeOneToOne,
    
    KSRelationshipTypeCount //number of relationship types in the enum.
}KSRelationshipType;

extern KSRelationshipType relationshipTypeFromString(NSString * relationshipString);

//Table Type constants

typedef enum
{
    KSTableTypeMain = 0,
    KSTableTypeOriginal,
    KSTableTypeHistory,
    
    KSTableTypeCount //number of table types in the enum.
}KSTableType;

extern NSString *tableTypeName(KSTableType tableType);

//Operation related constants

typedef enum
{
    KSOperationTypeDefault = 0,
    KSOperationTypeInitialGet,
    KSOperationTypeIncrementalGet,
    KSOperationTypeUpload,
    KSOperationTypeUploadResponse,
    
    KSOperationCount //number of operations in the enum.
}KSOperationType;

//Object Operation related constants

typedef enum
{
    KSObjectOperationTypeDefault = 0,
    KSObjectOperationTypeGet,
    KSObjectOperationTypeCreate,
    KSObjectOperationTypeUpdate,
    KSObjectOperationTypePartialUpdate,
    KSObjectOperationTypeDelete,
    
    KSObjectOperationCount //number of operations in the enum.
}KSObjectOperationType;

extern NSString* objectOperationTypeByName(KSObjectOperationType operationType);
extern KSObjectOperationType objectOperationForString(NSString * objectOperationType);
extern NSArray<NSString*>* objectOperationsAsStringArray(void);
extern KSSDKObjectRecordAction objectRecordActionFromOperationType(KSObjectOperationType operationType);

// -------------------------
// DOWNLOAD RESPONSE METADATA KEYS
// -------------------------
#define DOWNLOAD_RESPONSE_OBJECTS_KEY @"Objects"
#define RECORD_COUNT_KEY  @"recordCount"
#define CREATED_RECORDS_KEY @"createdRecords"
#define UPDATED_RECORDS_KEY @"updatedRecords"
#define PARTIAL_UPDATED_RECORDS_KEY @"partialUpdatedRecords"
#define DELETED_RECORDS_KEY @"deletedRecords"

extern NSString* recordActionTypeName(KSSDKObjectRecordAction recordAction);

@interface KSMetadataConstants : NSObject

@end
